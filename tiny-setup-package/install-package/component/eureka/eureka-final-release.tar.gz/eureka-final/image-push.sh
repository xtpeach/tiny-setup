#!/bin/bash
repo=registry.cn-hangzhou.aliyuncs.com/lanxy88
echo "Commit Docker Image (eureka:final) to Nexus Repository (${repo})"
docker login ${repo}
docker tag eureka:final ${repo}/eureka:final
docker push ${repo}/eureka:final
