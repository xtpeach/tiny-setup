#!/bin/bash
repo=registry.xtpeach.docker.images.com
echo "Commit Docker Image (eureka:final) to Nexus Repository (${repo})"
docker tag eureka:final ${repo}/eureka:final
docker push ${repo}/eureka:final
