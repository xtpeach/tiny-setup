#!/bin/bash
docker build --no-cache=true -t eureka:final .
