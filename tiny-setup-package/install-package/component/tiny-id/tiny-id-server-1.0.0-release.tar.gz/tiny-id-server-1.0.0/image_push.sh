repo=registry.xtpeach.docker.images.com
echo "Commit Docker Image (tiny-id-server:1.0.0) to Nexus Repository (${repo})"
docker tag tiny-id-server:1.0.0 ${repo}/tiny-id-server:1.0.0
docker push ${repo}/tiny-id-server:1.0.0
