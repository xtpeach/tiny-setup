docker build --no-cache=true -t tiny-id-server:1.0.0 .
