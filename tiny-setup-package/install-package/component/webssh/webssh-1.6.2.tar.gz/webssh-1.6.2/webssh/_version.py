__version_info__ = (1, 6, 2)
__version__ = '.'.join(map(str, __version_info__))
